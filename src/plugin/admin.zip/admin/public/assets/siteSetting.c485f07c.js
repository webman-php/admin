const n="https://github.com/anncwb/vue-vben-admin",t="https://vvbin.cn/doc-next/",s="https://vvbin.cn/next/";export{t as D,n as G,s as S};
