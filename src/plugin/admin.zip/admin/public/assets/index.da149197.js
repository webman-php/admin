import{R as o,C as r}from"./index.62d8a447.js";import{aq as a}from"./index.a50f1195.js";var l=a(o),m=a(r);export{m as C,l as R};
