import{B as o,R as e}from"./index.cd2734ff.js";o.install=function(n){return n.component(o.name,o),n.component(e.name,e),n};
